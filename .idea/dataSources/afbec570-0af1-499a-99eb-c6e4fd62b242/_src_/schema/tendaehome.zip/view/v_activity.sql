CREATE VIEW v_activity AS
  SELECT
    `a`.`id`                                                  AS `id`,
    `a`.`title`                                               AS `title`,
    `a`.`url`                                                 AS `url`,
    `a`.`range`                                               AS `range`,
    `a`.`start_date`                                          AS `start_date`,
    `a`.`end_date`                                            AS `end_date`,
    `a`.`use_type`                                            AS `use_type`,
    `a`.`user_group_id`                                       AS `user_group_id`,
    `a`.`maxPrice`                                            AS `maxPrice`,
    `a`.`minPrice`                                            AS `minPrice`,
    `a`.`type`                                                AS `type`,
    `a`.`num`                                                 AS `num`,
    coalesce((SELECT group_concat(`agd`.`goods_id` SEPARATOR ',')
              FROM `tendaehome`.`activity_goods` `agd`
              WHERE (`a`.`id` = `agd`.`act_id`)
              GROUP BY `agd`.`act_id`), '')                   AS `goods`,
    coalesce(group_concat(`ag`.`goods_id` SEPARATOR ','), '') AS `gift`,
    (CASE `a`.`type`
     WHEN 0
       THEN '满减'
     WHEN 1
       THEN '满赠'
     ELSE '折扣' END)                                           AS `type_name`
  FROM (`tendaehome`.`activity` `a` LEFT JOIN `tendaehome`.`activity_gift` `ag` ON ((`ag`.`act_id` = `a`.`id`)))
  GROUP BY `a`.`id`;
