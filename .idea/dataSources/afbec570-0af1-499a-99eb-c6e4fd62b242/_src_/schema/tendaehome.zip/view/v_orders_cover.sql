CREATE VIEW v_orders_cover AS
  SELECT
    `o`.`id`             AS `id`,
    `o`.`userid`         AS `userid`,
    `o`.`time`           AS `time`,
    `o`.`is_export`      AS `is_export`,
    `o`.`pay_way`        AS `pay_way`,
    `o`.`delivery_state` AS `delivery_state`,
    `o`.`refund_id`      AS `refund_id`,
    `o`.`total`          AS `total`,
    `o`.`num`            AS `num`,
    `o`.`create_time`    AS `create_time`,
    `o`.`state`          AS `state`,
    `o`.`address`        AS `address`,
    `o`.`order_num`      AS `order_num`,
    (CASE `o`.`state`
     WHEN 0
       THEN '取消订单'
     WHEN 1
       THEN '未付款'
     WHEN 2
       THEN '已付款，未发货'
     WHEN 3
       THEN '已发货，未签收'
     WHEN 4
       THEN '已签收，订单完成'
     WHEN 5
       THEN '退款中'
     ELSE '退款完成' END)    AS `status`
  FROM `tendaehome`.`v_orders` `o`;
