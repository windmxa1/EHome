CREATE VIEW v_user_feedback AS
  SELECT
    `uf`.`id`                                                    AS `id`,
    `uf`.`message`                                               AS `message`,
    `uf`.`user_id`                                               AS `user_id`,
    `uf`.`time`                                                  AS `time`,
    `uf`.`read`                                                  AS `read`,
    date_format(from_unixtime(`uf`.`time`), '%Y-%m-%d %H:%i:%S') AS `create_time`,
    `u`.`phone`                                                  AS `phone`
  FROM (`tendaehome`.`user_feedback` `uf` LEFT JOIN `tendaehome`.`user` `u` ON ((`u`.`id` = `uf`.`user_id`)));
