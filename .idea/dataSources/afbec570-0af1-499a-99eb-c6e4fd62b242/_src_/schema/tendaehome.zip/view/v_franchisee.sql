CREATE VIEW v_franchisee AS
  SELECT
    `f`.`id`                                               AS `id`,
    `f`.`franchisee_num`                                   AS `franchisee_num`,
    `f`.`nickname`                                         AS `nickname`,
    `f`.`name`                                             AS `name`,
    `f`.`address`                                          AS `address`,
    `f`.`phone`                                            AS `phone`,
    `f`.`health_pic`                                       AS `health_pic`,
    `f`.`promiss_pic`                                      AS `promiss_pic`,
    `f`.`ipc`                                              AS `ipc`,
    `f`.`lat`                                              AS `lat`,
    `f`.`lon`                                              AS `lon`,
    `f`.`userid`                                           AS `userid`,
    `f`.`catalog_id`                                       AS `catalog_id`,
    `f`.`state`                                            AS `state`,
    `f`.`description`                                      AS `description`,
    cast(coalesce(avg(`c`.`rating`), 0) AS DECIMAL(11, 2)) AS `rating`
  FROM
    ((`tendaehome`.`franchisee` `f` LEFT JOIN `tendaehome`.`orders` `o` ON ((`o`.`franchisee_id` = `f`.`id`))) LEFT JOIN
      `tendaehome`.`comment` `c` ON ((`c`.`order_id` = `o`.`id`)))
  GROUP BY `f`.`id`;
