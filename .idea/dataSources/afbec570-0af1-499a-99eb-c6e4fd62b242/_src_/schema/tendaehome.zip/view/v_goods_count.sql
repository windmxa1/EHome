CREATE VIEW v_goods_count AS
  SELECT
    `od`.`goods_id` AS `goods_id`,
    sum(`od`.`num`) AS `count`
  FROM (`tendaehome`.`orders_detail` `od`
    JOIN `tendaehome`.`orders` `o`)
  WHERE ((`o`.`pay_way` > 0) AND (`o`.`id` = `od`.`order_id`))
  GROUP BY `od`.`goods_id`;
