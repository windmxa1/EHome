CREATE VIEW v_order_total AS
  SELECT
    `od`.`order_id`                                         AS `order_id`,
    cast(sum((`g`.`price` * `od`.`num`)) AS DECIMAL(11, 2)) AS `total`,
    cast(sum(`od`.`num`) AS UNSIGNED)                       AS `num`
  FROM (`tendaehome`.`goods` `g`
    JOIN `tendaehome`.`orders_detail` `od`)
  WHERE (`g`.`id` = `od`.`goods_id`)
  GROUP BY `od`.`order_id`;
