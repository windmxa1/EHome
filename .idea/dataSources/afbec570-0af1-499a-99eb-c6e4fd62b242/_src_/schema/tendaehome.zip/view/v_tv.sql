CREATE VIEW v_tv AS
  SELECT
    `t`.`id`                                                      AS `id`,
    `t`.`name`                                                    AS `name`,
    concat('http://39.108.82.55:8080/TendaEHome/', `t`.`img_url`) AS `img_url`,
    `t`.`tv_url`                                                  AS `tv_url`,
    `t`.`time`                                                    AS `time`,
    date_format(from_unixtime(`t`.`time`), '%Y-%m-%d %H:%i:%S')   AS `create_time`,
    `t`.`available`                                               AS `available`
  FROM `tendaehome`.`tv` `t`
  ORDER BY `t`.`time` DESC;
