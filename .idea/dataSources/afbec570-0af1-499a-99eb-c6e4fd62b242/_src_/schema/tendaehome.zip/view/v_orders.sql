CREATE VIEW v_orders AS
  SELECT
    `o`.`id`                                                      AS `id`,
    `o`.`userid`                                                  AS `userid`,
    `o`.`time`                                                    AS `time`,
    `o`.`is_export`                                               AS `is_export`,
    `o`.`pay_way`                                                 AS `pay_way`,
    `o`.`delivery_state`                                          AS `delivery_state`,
    `o`.`refund_id`                                               AS `refund_id`,
    `o`.`after_sale_state`                                        AS `after_sale_state`,
    `o`.`franchisee_id`                                           AS `franchisee_id`,
    `o`.`type`                                                    AS `type`,
    `o`.`remarks`                                                 AS `remarks`,
    `o`.`address`                                                 AS `address`,
    `o`.`order_num`                                               AS `order_num`,
    `o`.`is_comment`                                              AS `is_comment`,
    (SELECT `vot`.`total`
     FROM `tendaehome`.`v_order_total` `vot`
     WHERE (`vot`.`order_id` = `o`.`id`))                         AS `total`,
    (SELECT `vot`.`num`
     FROM `tendaehome`.`v_order_total` `vot`
     WHERE (`vot`.`order_id` = `o`.`id`))                         AS `num`,
    coalesce((SELECT `f`.`nickname`
              FROM `tendaehome`.`franchisee` `f`
              WHERE (`o`.`franchisee_id` = `f`.`id`)), '')        AS `franchisee_name`,
    coalesce((SELECT `s`.`staff_name`
              FROM `tendaehome`.`staff` `s`
              WHERE (`o`.`staff_no` = `s`.`staff_no`)), '暂未绑定职工') AS `staff_name`,
    date_format(from_unixtime(`o`.`time`), '%Y-%m-%d %H:%i:%S')   AS `create_time`,
    (CASE WHEN (`o`.`refund_id` > 0)
      THEN (CASE `r`.`state`
            WHEN 0
              THEN 5
            WHEN -(1)
              THEN 7
            WHEN -(2)
              THEN 8
            ELSE 6 END)
     WHEN (`o`.`delivery_state` = 2)
       THEN 4
     WHEN (`o`.`delivery_state` = 1)
       THEN 3
     WHEN (`o`.`pay_way` > 0)
       THEN 2
     WHEN (`o`.`pay_way` = -(1))
       THEN 0
     ELSE 1 END)                                                  AS `state`,
    (CASE WHEN (`o`.`refund_id` > 0)
      THEN (CASE `r`.`state`
            WHEN 0
              THEN '退款中'
            WHEN -(1)
              THEN '退款异常'
            WHEN -(2)
              THEN '退款关闭'
            ELSE '退款完成' END)
     WHEN (`o`.`delivery_state` = 2)
       THEN '交易完成'
     WHEN (`o`.`delivery_state` = 1)
       THEN '等待签收'
     WHEN (`o`.`pay_way` > 0)
       THEN '等待发货'
     WHEN (`o`.`pay_way` = -(1))
       THEN '订单已取消'
     ELSE '未付款' END)                                              AS `status`
  FROM (`tendaehome`.`orders` `o` LEFT JOIN `tendaehome`.`refund` `r` ON ((`r`.`order_id` = `o`.`id`)))
  ORDER BY `o`.`time` DESC;
