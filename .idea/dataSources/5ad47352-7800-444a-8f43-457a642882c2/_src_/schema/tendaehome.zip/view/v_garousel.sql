CREATE VIEW v_garousel AS
  SELECT
    `g`.`id`                                                    AS `id`,
    `g`.`title`                                                 AS `title`,
    `g`.`url`                                                   AS `url`,
    `g`.`catalog_id`                                            AS `catalog_id`,
    `g`.`hyperlink`                                             AS `hyperlink`,
    `g`.`time`                                                  AS `time`,
    (SELECT `gc`.`garousel_catalog`
     FROM `tendaehome`.`garousel_catalog` `gc`
     WHERE (`gc`.`id` = `g`.`catalog_id`))                      AS `catalog`,
    concat('http://39.108.82.55:8080/TendaEHome/', `g`.`url`)   AS `gerousel_url`,
    date_format(from_unixtime(`g`.`time`), '%Y-%m-%d %H:%i:%S') AS `create_time`
  FROM `tendaehome`.`garousel` `g`;
