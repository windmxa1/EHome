CREATE VIEW v_orders_details AS
  SELECT
    `od`.`id`                                                          AS `id`,
    `od`.`order_id`                                                    AS `order_id`,
    (SELECT `o`.`order_num`
     FROM `tendaehome`.`orders` `o`
     WHERE (`o`.`id` = `od`.`order_id`))                               AS `order_num`,
    `od`.`goods_id`                                                    AS `goods_id`,
    `g`.`name`                                                         AS `goods_name`,
    `g`.`type`                                                         AS `type`,
    `g`.`origin`                                                       AS `origin`,
    (SELECT concat((`od`.`num` * `g`.`unit_num`), `g`.`unit_name`))    AS `total_num`,
    (SELECT concat('http://39.108.82.55:8080/TendaEHome/', `g`.`url`)) AS `goods_url`,
    `od`.`num`                                                         AS `num`,
    cast((SELECT (`od`.`num` * `g`.`price`)) AS DECIMAL(11, 2))        AS `prices`
  FROM (`tendaehome`.`orders_detail` `od` LEFT JOIN `tendaehome`.`goods` `g` ON ((`od`.`goods_id` = `g`.`id`)));
