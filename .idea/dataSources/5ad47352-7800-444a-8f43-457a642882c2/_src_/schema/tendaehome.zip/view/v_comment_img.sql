CREATE VIEW v_comment_img AS
  SELECT
    `ci`.`id`                                                  AS `id`,
    `ci`.`url`                                                 AS `url`,
    `ci`.`comment_id`                                          AS `comment_id`,
    concat('http://39.108.82.55:8080/TendaEHome/', `ci`.`url`) AS `img_url`
  FROM `tendaehome`.`comment_img` `ci`;
