CREATE VIEW v_user AS
  SELECT
    `u`.`id`                                                       AS `id`,
    `u`.`phone`                                                    AS `phone`,
    `u`.`password`                                                 AS `password`,
    `u`.`time`                                                     AS `time`,
    `u`.`nickname`                                                 AS `nickname`,
    `u`.`head_url`                                                 AS `head_url`,
    date_format(from_unixtime(`u`.`time`), '%Y-%m-%d %H:%i:%S')    AS `create_time`,
    concat('http://39.108.82.55:8080/TendaEHome/', `u`.`head_url`) AS `url`,
    coalesce(`ua`.`address`, '')                                   AS `address`,
    coalesce(`ua`.`id`, 0)                                         AS `address_id`,
    `u`.`is_free`                                                  AS `is_free`
  FROM (`tendaehome`.`user` `u` LEFT JOIN `tendaehome`.`v_user_address` `ua` ON ((`ua`.`userid` = `u`.`id`)));
