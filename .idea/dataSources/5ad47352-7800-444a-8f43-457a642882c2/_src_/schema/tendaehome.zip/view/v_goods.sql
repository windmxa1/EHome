CREATE VIEW v_goods AS
  SELECT
    `g`.`id`                                                    AS `goods_id`,
    `g`.`name`                                                  AS `name`,
    `g`.`price`                                                 AS `price`,
    `g`.`url`                                                   AS `url`,
    `g`.`catalog_id`                                            AS `catalog_id`,
    `g`.`description`                                           AS `description`,
    `g`.`time`                                                  AS `time`,
    `g`.`state`                                                 AS `state`,
    `g`.`sale_num`                                              AS `sale_num`,
    `g`.`origin_price`                                          AS `origin_price`,
    `g`.`type`                                                  AS `type`,
    coalesce(group_concat(`a`.`type` SEPARATOR ','), 0)         AS `act_type`,
    coalesce(group_concat(`a`.`id` SEPARATOR ','), 0)           AS `act_id`,
    coalesce(group_concat(`a`.`title` SEPARATOR ','), '')       AS `act_name`,
    (CASE `g`.`state`
     WHEN 1
       THEN '上架'
     WHEN 0
       THEN '下架'
     ELSE '已删除' END)                                            AS `status`,
    concat(`g`.`unit_num`, `g`.`unit_name`)                     AS `unit`,
    date_format(from_unixtime(`g`.`time`), '%Y-%m-%d %H:%i:%S') AS `create_time`,
    (SELECT `gc`.`catalog`
     FROM `tendaehome`.`goods_catalog` `gc`
     WHERE (`g`.`catalog_id` = `gc`.`id`))                      AS `catalog`,
    cast(coalesce(`vgc`.`count`, 0) AS UNSIGNED)                AS `count`,
    concat('http://39.108.82.55:8080/TendaEHome/', `g`.`url`)   AS `goods_url`,
    `g`.`origin`                                                AS `origin`
  FROM (((`tendaehome`.`goods` `g` LEFT JOIN `tendaehome`.`v_goods_count` `vgc`
      ON ((`vgc`.`goods_id` = `g`.`id`))) LEFT JOIN `tendaehome`.`activity_goods` `ag`
      ON ((`ag`.`goods_id` = `g`.`id`))) LEFT JOIN `tendaehome`.`activity` `a` ON ((`ag`.`act_id` = `a`.`id`)))
  GROUP BY `g`.`id`;
