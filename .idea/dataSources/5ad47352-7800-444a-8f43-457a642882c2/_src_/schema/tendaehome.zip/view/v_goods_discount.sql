CREATE VIEW v_goods_discount AS
  SELECT
    `gd`.`id`                                                          AS `id`,
    `gd`.`goods_id`                                                    AS `goods_id`,
    `gd`.`start_time`                                                  AS `start_time`,
    `gd`.`end_time`                                                    AS `end_time`,
    `gd`.`discount`                                                    AS `discount`,
    date_format(from_unixtime(`gd`.`start_time`), '%Y-%m-%d %H:%i:%S') AS `start_date`,
    date_format(from_unixtime(`gd`.`end_time`), '%Y-%m-%d %H:%i:%S')   AS `end_date`,
    cast((`gd`.`discount` * `g`.`price`) AS DECIMAL(11, 2))            AS `dis_price`
  FROM (`tendaehome`.`goods_discount` `gd`
    JOIN `tendaehome`.`goods` `g`)
  WHERE
    ((unix_timestamp(now()) BETWEEN `gd`.`start_time` AND (`gd`.`end_time` + 86400)) AND (`g`.`id` = `gd`.`goods_id`)
     AND ((`gd`.`end_time` + 86400) <> unix_timestamp(now())));
