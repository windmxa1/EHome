CREATE VIEW v_repair_order AS
  SELECT
    `ro`.`id`               AS `id`,
    `ro`.`appointment_time` AS `appointment_time`,
    `ro`.`address`          AS `address`,
    `ro`.`description`      AS `description`,
    `ro`.`phone`            AS `phone`,
    `ro`.`status`           AS `status`,
    `ro`.`handle_result`    AS `handle_result`,
    `ro`.`userid`           AS `userid`,
    `ro`.`staff_id`         AS `staff_id`,
    `ro`.`is_read`          AS `is_read`,
    `ro`.`is_staff_read`    AS `is_staff_read`,
    `ro`.`lat`              AS `lat`,
    `ro`.`lon`              AS `lon`,
    (CASE `ro`.`status`
     WHEN 0
       THEN '未处理'
     WHEN 1
       THEN '处理中'
     ELSE '处理完成' END)       AS `state`
  FROM `tendaehome`.`repair_order` `ro`;
