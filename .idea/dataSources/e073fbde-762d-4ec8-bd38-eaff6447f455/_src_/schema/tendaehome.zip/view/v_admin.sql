CREATE VIEW v_admin AS
  SELECT
    `a`.`id`                                                    AS `id`,
    `a`.`username`                                              AS `username`,
    `a`.`password`                                              AS `password`,
    `a`.`time`                                                  AS `time`,
    date_format(from_unixtime(`a`.`time`), '%Y-%m-%d %H:%i:%S') AS `create_time`
  FROM `tendaehome`.`admin` `a`;
