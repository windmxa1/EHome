CREATE VIEW v_comment AS
  SELECT
    `c`.`id`                                                       AS `id`,
    `c`.`description`                                              AS `description`,
    `c`.`rating`                                                   AS `rating`,
    `c`.`userid`                                                   AS `userid`,
    `c`.`order_id`                                                 AS `order_id`,
    `c`.`is_visable`                                               AS `is_visable`,
    `c`.`time`                                                     AS `time`,
    `c`.`reply`                                                    AS `reply`,
    concat('http://39.108.82.55:8080/TendaEHome/', `u`.`head_url`) AS `head_img`,
    coalesce(`f`.`catalog_id`, 0)                                  AS `catalog_id`,
    coalesce(`f`.`nickname`, '')                                   AS `franchisee_name`,
    `u`.`nickname`                                                 AS `nickname`,
    coalesce(group_concat(`ci`.`img_url` SEPARATOR ','), '')       AS `img_url`
  FROM ((((`tendaehome`.`comment` `c` LEFT JOIN `tendaehome`.`orders` `o` ON ((`c`.`order_id` = `o`.`id`))) LEFT JOIN
    `tendaehome`.`franchisee` `f` ON ((`o`.`franchisee_id` = `f`.`id`))) LEFT JOIN `tendaehome`.`user` `u`
      ON ((`u`.`id` = `c`.`userid`))) LEFT JOIN `tendaehome`.`v_comment_img` `ci` ON ((`c`.`id` = `ci`.`comment_id`)))
  GROUP BY `c`.`id`;
