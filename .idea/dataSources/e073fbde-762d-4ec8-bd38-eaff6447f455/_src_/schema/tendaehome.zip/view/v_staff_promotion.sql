CREATE VIEW v_staff_promotion AS
  SELECT
    `sp`.`id`                      AS `id`,
    `sp`.`address`                 AS `address`,
    `sp`.`staff_no`                AS `staff_no`,
    `sp`.`time`                    AS `time`,
    coalesce(`s`.`staff_name`, '') AS `staff_name`
  FROM (`tendaehome`.`staff_promotion` `sp` LEFT JOIN `tendaehome`.`staff` `s` ON ((`s`.`staff_no` = `sp`.`staff_no`)));
