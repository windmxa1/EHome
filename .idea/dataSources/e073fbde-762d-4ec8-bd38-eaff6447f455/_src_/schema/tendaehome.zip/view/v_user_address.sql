CREATE VIEW v_user_address AS
  SELECT
    `u`.`id`                                                                       AS `userid`,
    `ua`.`id`                                                                      AS `id`,
    concat(`ua`.`receiver`, ' ', `ua`.`sex`, ' ', `ua`.`tel`, ' ', `ua`.`address`) AS `address`
  FROM (`tendaehome`.`user_address` `ua`
    JOIN `tendaehome`.`user` `u`)
  WHERE ((`u`.`id` = `ua`.`userid`) AND (`ua`.`default_` = 1));
